#include <err.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "mpi.h"


#define RSEED 92349278	/* seed for the prng */

static int *createTestArray(int);
int intComp(const void *, const void *);

int
main(int argc, char **argv)
{
	double start, end;
	FILE *fp;
	int rank, size, nInts, *toSort;

	MPI_Init(&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &size);

	nInts = atoi(argv[1]);
	fp = fopen(argv[2], "a");

	toSort = createTestArray(nInts);
	start = MPI_Wtime();
	qsort(toSort, nInts, sizeof(int), intComp);
	end = MPI_Wtime();
	fprintf(fp, "Sorintg %d ints sequentially took %f seconds.\n", nInts,
	    end-start);
	MPI_Finalize();
	return 0;
}

int
intComp(const void *a, const void *b)
{
	int *x = (int *)a, *y = (int *)b;
	if (*x > *y) return 1;
	if (*x < *y) return -1;
	return 0;
}
static int *
createTestArray(int nInts) 
{
	int *ints = NULL, i;
	srandom(RSEED);

	ints = calloc(1, sizeof(int)*nInts); 
	if (!ints) {
		err(1, "Failed to allocate memory for list of integers to"
		    " sort!");
		exit(EXIT_FAILURE);
	}


	for (i = 0; i < nInts; i++) {
		ints[i] = random() % INT_MAX;
	}

	return ints;
}
